# Autossential

A set of custom activities built with Windows Workflow Foundation API to be used in RPA tools like UiPath and related.
