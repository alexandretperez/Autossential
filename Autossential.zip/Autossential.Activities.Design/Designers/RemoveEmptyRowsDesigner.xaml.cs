﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for RemoveEmptyRowsDesigner.xaml
    public partial class RemoveEmptyRowsDesigner
    {
        public RemoveEmptyRowsDesigner()
        {
            InitializeComponent();
        }
    }
}