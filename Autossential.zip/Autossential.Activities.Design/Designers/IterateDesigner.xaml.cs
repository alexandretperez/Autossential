﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for IterateDesigner.xaml
    public partial class IterateDesigner
    {
        public IterateDesigner()
        {
            InitializeComponent();
        }
    }
}