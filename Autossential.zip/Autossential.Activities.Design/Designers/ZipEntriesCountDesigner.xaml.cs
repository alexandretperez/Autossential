﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for ZipEntriesCountDesigner.xaml
    public partial class ZipEntriesCountDesigner
    {
        public ZipEntriesCountDesigner()
        {
            InitializeComponent();
        }
    }
}
