﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for ZipDesigner.xaml
    public partial class ZipDesigner
    {
        public ZipDesigner()
        {
            InitializeComponent();
        }
    }
}