﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for CheckPointDesigner.xaml
    public partial class CheckPointDesigner
    {
        public CheckPointDesigner()
        {
            InitializeComponent();
        }
    }
}