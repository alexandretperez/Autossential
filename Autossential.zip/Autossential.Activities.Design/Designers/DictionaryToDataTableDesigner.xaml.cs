﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for DictionaryToDataTableDesigner.xaml
    public partial class DictionaryToDataTableDesigner
    {
        public DictionaryToDataTableDesigner()
        {
            InitializeComponent();
        }
    }
}