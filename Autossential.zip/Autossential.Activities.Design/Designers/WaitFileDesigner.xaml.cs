﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for WaitFileDesigner.xaml
    public partial class WaitFileDesigner
    {
        public WaitFileDesigner()
        {
            InitializeComponent();
        }
    }
}