﻿namespace Autossential.Activities.Design.Designers
{
    // Interaction logic for ExitDesigner.xaml
    public partial class ExitDesigner
    {
        public ExitDesigner()
        {
            InitializeComponent();
        }
    }
}