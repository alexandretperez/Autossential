﻿namespace Autossential.Enums
{
    public enum DataRowValuesMode
    {
        All,
        Any,
        Custom
    }
}