﻿namespace Autossential.Enums
{
    public enum StopwatchMethods
    {
        Start,
        Stop,
        Reset,
        Restart
    }
}