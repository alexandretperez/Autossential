﻿namespace Autossential.Enums
{
    public enum SymmetricAlgorithms
    {
        AES,
        DES,
        RC2,
        Rijndael,
        TripleDES
    }
}