﻿namespace Autossential.Enums
{
    public enum ConditionOperator
    {
        And,
        Or
    }
}